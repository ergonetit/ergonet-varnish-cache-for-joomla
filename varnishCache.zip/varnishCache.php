<?php
/**
 * @package    Joomla
 *
 * @author     Ergonet srl <info@ergonet.it>
 * @copyright  A copyright
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * @link       https://www.ergonet.it
 */

defined('_JEXEC') or die;

/**
 * Joomla plugin.
 *
 * @package   varnishCache
 * @since     1.0.0
 */

class plgSystemVarnishCache extends JPlugin
{
    function onContentAfterSave($context, $article, $isNew)
    {
        if (get_class($article) != "Joomla\CMS\Table\Content") {
           return true;
        }
        
        $rootURL = rtrim(JURI::base(),'/');
        $subpathURL = JURI::base(true);
        if(!empty($subpathURL) && ($subpathURL != '/')) {
            $rootURL = substr($rootURL, 0, -1 * strlen($subpathURL));
        }

        $app    = JApplication::getInstance('site');
        $router = &$app->getRouter();
        $newUrl = JRoute::_(ContentHelperRoute::getArticleRoute($article->id.':'.$article->alias, $article->catid));
        $newUrl = $router->build($newUrl);
        $parsed_url = $newUrl->toString();
        $parsed_url = str_replace(JURI::base(true), '', $parsed_url);
        $parsed_url = $rootURL.$parsed_url;

        $wwwparsed_url = str_replace('://', '://www.', $parsed_url);
        $wwwrootURL = str_replace('://', '://www.', $rootURL);

        $this->execCachePurge($parsed_url);
        $this->execCachePurge($wwwparsed_url);
        $this->execCachePurge($rootURL);
        $this->execCachePurge($wwwrootURL);

        JFactory::getApplication()->enqueueMessage('Aggiornamento della cache Varnish avvenuto correttamente.');

        return true;
    }

    function onUserAfterLogin($options)
    {
        $app    = JApplication::getInstance('site');
        $lifetime = $this->params->get('cookie_lifetime', 60) * 24 * 60 * 60;
        $token    = JUserHelper::genRandomPassword(16);

        setcookie("joomla_logged_in", $token, time()+$lifetime);

        return true;
    }

    function onUserAfterLogout($options)
    {
        unset($_COOKIE['joomla_logged_in']);
        setcookie("joomla_logged_in", '', time()-3600);

        return true;
    }

    function execCachePurge( $url )
    {
        $curl = curl_init();
        curl_setopt($curl,CURLOPT_USERAGENT,'joomla_purgeCache');
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PURGE");
        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($curl,CURLOPT_URL, $url);
        $response=curl_exec($curl);
        curl_close($curl);

        return true;
    }
}